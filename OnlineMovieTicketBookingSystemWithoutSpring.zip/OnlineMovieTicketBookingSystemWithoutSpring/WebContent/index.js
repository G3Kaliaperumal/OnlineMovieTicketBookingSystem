/**
 * 
 */
function validate(){
    var uname = document.getElementById('uname').value;
    var x = true, y= true;
    if(uname == null || uname == undefined || uname == ""){
        alert("Kindly enter username");
         return false;
    }
    var pswd = document.getElementById('pword').value;
    if(pswd == null || pswd == undefined || pswd == ""){
        alert("Kindly enter password");
        return false;
    }
    if(x != false && y != false){
        return true;
    }
};
/*function submitAction(act)
{
    document.registerForm.action = act;
    if(validate()){
        document.registerForm.submit();
    }
};*/