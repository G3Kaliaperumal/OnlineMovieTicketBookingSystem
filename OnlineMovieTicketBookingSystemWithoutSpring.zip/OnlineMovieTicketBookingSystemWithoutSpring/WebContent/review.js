function validate() {
	var movie = document.forms["myForm"]["movie"].value;
	var rating = document.forms["myForm"]["rating"].value;
	
	if (movie == "" && rating == "") {
		alert("Please Enter MovieName and MovieRating");
		return false;
	} else if (rating == "") {
		alert("Please Enter MovieRating");
		return false;
	} else if(movie == ""){
		alert("Please Enter MovieName");
		return false;
	} else{
		return true;
	}
}