package com.inautix.XBBNHBS.ServletController;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.inautix.XBBNHBS.Movie.MovieDao;

public class BookTicketServlet extends HttpServlet{
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
		try {
			bookTicket(request, response);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void bookTicket(HttpServletRequest request,
			HttpServletResponse response) throws IOException, ClassNotFoundException, ServletException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession(false);
		MovieDao movieDao = new MovieDao();
		String movieName = request.getParameter("moviesList");
		String noOfSeats = request.getParameter("noOfSeats");
		String discountCode = request.getParameter("discountCodes");
		String ticketType = request.getParameter("ticketTypes");
		int seats = Integer.parseInt(noOfSeats);
		int discountAmount = 0 ;
		if(discountCode != ""){
			discountAmount = movieDao.getDiscountAmount(discountCode);
		}
		int ticketAmount = movieDao.getAmount(ticketType);
		int totalAmount = (seats * ticketAmount) - discountAmount;
		int movieId = movieDao.getMovieId(movieName);
		session.setAttribute("movieId", movieId);
		session.setAttribute("movieName", movieName);
		session.setAttribute("discountCode", discountCode);
		session.setAttribute("ticketType", ticketType);
		session.setAttribute("noOfSeats", seats);
		session.setAttribute("totalAmount", totalAmount);
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("theatre.jsp");
		requestDispatcher.forward(request, response);
		
	}
}
