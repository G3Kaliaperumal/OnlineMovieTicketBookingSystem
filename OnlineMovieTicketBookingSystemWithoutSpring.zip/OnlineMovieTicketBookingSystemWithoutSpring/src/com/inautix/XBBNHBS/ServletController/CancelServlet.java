package com.inautix.XBBNHBS.ServletController;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CancelServlet extends HttpServlet{
protected void doPost(HttpServletRequest request, HttpServletResponse response){ 
 System.out.println("cancelled");
}
}
