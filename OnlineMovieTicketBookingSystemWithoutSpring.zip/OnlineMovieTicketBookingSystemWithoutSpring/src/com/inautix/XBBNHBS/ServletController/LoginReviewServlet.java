package com.inautix.XBBNHBS.ServletController;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.inautix.XBBNHBS.Login.Login;
import com.inautix.XBBNHBS.Login.LoginBean;

public class LoginReviewServlet extends HttpServlet{
	public void doPost(HttpServletRequest request, HttpServletResponse response)  
	        throws ServletException, IOException{
		try {
			validateRater(request, response);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}

	private void validateRater(HttpServletRequest request,
			HttpServletResponse response) throws IOException, ClassNotFoundException, ServletException {
		// TODO Auto-generated method stub
		LoginBean loginBean = new LoginBean();
		Login login = new Login();
		boolean result = false;
		
		response.setContentType("text/html");  
	    PrintWriter out = response.getWriter(); 
	    
	    String userName = request.getParameter("userName");
	    String password = request.getParameter("password");
	    
	    loginBean.setUserName(userName);
	    loginBean.setPassword(password);
	    
	    result = login.validateRater(loginBean);
	    
	    if(result){
	    	RequestDispatcher requestDispatcher = request.getRequestDispatcher("review.jsp");
	    	HttpSession session = request.getSession(true);
	    	session.setAttribute("userName", userName);
	    	requestDispatcher.forward(request, response); 
	    }
	    else{
	    	out.print("Sorry UserName or Password Error!");
	    	RequestDispatcher requestDispatcher = request.getRequestDispatcher("/loginReview.html");
	    	requestDispatcher.include(request, response);
	    }
	    
	}
}
