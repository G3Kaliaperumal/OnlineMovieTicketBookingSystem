package com.inautix.XBBNHBS.ServletController;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.inautix.XBBNHBS.Movie.MovieBean;
import com.inautix.XBBNHBS.Movie.MovieDao;
import com.inautix.XBBNHBS.MovieRate.MovieRateBean;
import com.inautix.XBBNHBS.MovieRate.MovieRateDao;

public class MovieReview extends HttpServlet{

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		
		movieReview(request,response);
		
	}

	private void movieReview(HttpServletRequest request,
			HttpServletResponse response) throws IOException, ServletException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		MovieRateBean movieRater = new MovieRateBean();
		MovieRateDao movieRateDao = new MovieRateDao();
		MovieDao movieDao = new MovieDao();
		String movieName = request.getParameter("movie");
		String rating = request.getParameter("rating");
		int movieRate = Integer.parseInt(rating);
		try{
			if(movieRate < 1 || movieRate > 5){
				throw new Exception("Invalid Movie Rating. Movie Rating should be between 1 to 5");
			}
			HttpSession session = request.getSession(false);
			String userName = (String)session.getAttribute("userName"); 
			int movieRaterId = 0;
			movieRaterId = movieRateDao.getMovieRaterId(userName);
			int movieId = 0;
			movieId = movieDao.getMovieId(movieName);
			try{
				if(movieId == -1){
					throw new Exception("Invalid Movie Name!! Please enter the Movie Name as mentioned below. Also, remember they are Case Sensitive.\n");
				}
				movieRater.setMovieId(movieId);
				movieRater.setMovieRate(movieRate);
				movieRater.setMovieRaterId(movieRaterId);
				movieRateDao.setMovieRatings(movieRater);
				RequestDispatcher requestDispatcher = request.getRequestDispatcher("ThankYou.jsp");
				requestDispatcher.include(request, response);
			}	
			catch(Exception e){
				out.println(e.getMessage());
				List<MovieBean> moviesList= movieDao.getAvailableMovies();
				request.setAttribute("moviesList", moviesList);
				RequestDispatcher requestDispatcher = request.getRequestDispatcher("reviewError.jsp");
				requestDispatcher.include(request, response);
			}
		}
		catch(Exception e){
			out.println(e.getMessage());
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("review.jsp");
			requestDispatcher.include(request, response);
		}
		
	}
}
