package com.inautix.XBBNHBS.ServletController;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.inautix.XBBNHBS.MovieRate.MovieRateBean;
import com.inautix.XBBNHBS.MovieRate.MovieRateDao;

public class ViewReviewsServlet extends HttpServlet{
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		try {
			viewReviews(request, response);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void viewReviews(HttpServletRequest request,
			HttpServletResponse response) throws ClassNotFoundException, ServletException, IOException {
		// TODO Auto-generated method stub
		MovieRateDao movieRateDao = new MovieRateDao();
		List<MovieRateBean> movieRateList = movieRateDao.getRatings();
		request.setAttribute("RatingList", movieRateList);
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("ViewReview.jsp");
		requestDispatcher.forward(request, response);
	}
}
