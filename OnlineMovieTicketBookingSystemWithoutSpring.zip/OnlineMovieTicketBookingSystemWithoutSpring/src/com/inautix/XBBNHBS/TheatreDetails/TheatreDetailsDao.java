package com.inautix.XBBNHBS.TheatreDetails;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import com.inautix.XBBNHBS.Movie.Movie;

import DBUtil.ConnectionManager;

public class TheatreDetailsDao {

	public List<TheatreDetailsBean> getTheatreDetails(int movieId) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		List<TheatreDetailsBean> theatresList = new ArrayList<TheatreDetailsBean>();
		Connection con = ConnectionManager.getDBConnection();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String query = "Select * from T_XBBNHBS_TheatreDetails where movieId = ?";
		try{
			stmt= con.prepareStatement(query);
			stmt.setInt(1, movieId);
			rs = stmt.executeQuery();
			while(rs.next()){
				TheatreDetailsBean theatre = new TheatreDetailsBean();
				theatre.setTheatreId(rs.getInt(1));
				theatre.setTheatreName(rs.getString(2));
				theatre.setFromTime(rs.getString(3));
				theatre.setToTime(rs.getString(4));
				theatresList.add(theatre);
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally
		{
			if(rs!=null)
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(stmt!=null)
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			try {
				con.commit();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return theatresList;
	}

	/*public String getFromTime(String movieName) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		String fromTime = null;
		Movie movie = new Movie();
		Connection con = ConnectionManager.getDBConnection();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String query = "Select fromTime from T_XBBNHBS_TheatreDetails where movieId = ?";
		try{
			stmt= con.prepareStatement(query);
			stmt.setInt(1, movie.getMovieId(movieName));
			rs = stmt.executeQuery();
			while(rs.next()){
				fromTime = rs.getString(1);
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally
		{
			if(rs!=null)
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(stmt!=null)
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			try {
				con.commit();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return fromTime;
	}

	public String getEndTime(String movieName) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		Timestamp endTime = null;
		Movie movie = new Movie();
		Connection con = ConnectionManager.getDBConnection();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String query = "Select toTime from T_XBBNHBS_TheatreDetails where movieId = ?";
		try{
			stmt= con.prepareStatement(query);
			stmt.setInt(1, movie.getMovieId(movieName));
			rs = stmt.executeQuery();
			while(rs.next()){
				endTime = rs.getTimestamp(1);
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally
		{
			if(rs!=null)
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(stmt!=null)
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			try {
				con.commit();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return endTime;
	}
*/
	
	public int getTheatreId(String theatreName) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		int theatreId = 0;
		Connection con = ConnectionManager.getDBConnection();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String query = "Select theatreId from T_XBBNHBS_TheatreDetails where theatreName = ?";
		try{
			stmt= con.prepareStatement(query);
			stmt.setString(1, theatreName);
			rs = stmt.executeQuery();
			while(rs.next()){
				theatreId = rs.getInt(1);
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally
		{
			if(rs!=null)
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(stmt!=null)
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			try {
				con.commit();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return theatreId;
	}
	
	public String getTheatreName(int theatreId) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		String theatreName = "";
		Connection con = ConnectionManager.getDBConnection();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String query = "Select theatreName from T_XBBNHBS_TheatreDetails where theatreId = ?";
		try{
			stmt= con.prepareStatement(query);
			stmt.setInt(1, theatreId);
			rs = stmt.executeQuery();
			while(rs.next()){
				theatreName = rs.getString(1);
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally
		{
			if(rs!=null)
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(stmt!=null)
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			try {
				con.commit();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return theatreName;
	}
	
	public int getSeats(String ticketType, int movieId, int theatreId, int noOfSeats, String fromTime, String toTime) throws ClassNotFoundException{
		int seats = 0;
		PreparedStatement stmt = null;
		PreparedStatement stmt1 = null;
		String query = "Select "+ticketType+" from T_XBBNHBS_TheatreDetails where movieId=? and theatreId = ? and fromTime = ? and toTime = ?";
		String query1 = "update T_XBBNHBS_TheatreDetails set "+ticketType+" = ? where movieId=? and theatreId = ? and fromTime = ? and toTime = ?";
		ResultSet rs = null;
		Connection con = ConnectionManager.getDBConnection();
		try{
			stmt = con.prepareStatement(query);
			stmt.setInt(1, movieId);
			stmt.setInt(2, theatreId);
			stmt.setString(3, fromTime);
			stmt.setString(4, toTime);
			rs = stmt.executeQuery();
			while(rs.next()){
				seats = rs.getInt(1);
				if(seats >= noOfSeats){
					int remainingSeats = seats - noOfSeats;
					stmt1 = con.prepareStatement(query1);
					stmt1.setInt(1, remainingSeats);
					stmt1.setInt(2, movieId);
					stmt1.setInt(3, theatreId);
					stmt1.setString(4, fromTime);
					stmt1.setString(5, toTime);
					stmt1.executeUpdate();
				}
				else{
					seats = 0;
				}
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally
		{
			if(rs!=null)
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(stmt!=null)
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			try {
				con.commit();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return seats;
	}
}
