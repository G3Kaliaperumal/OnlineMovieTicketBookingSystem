create table T_XBBNHBS_Movie(movieId number primary key,
movieName varchar(30))
insert into T_XBBNHBS_Movie(movieId, movieName) values(1, 'Fantastic Four');
insert into T_XBBNHBS_Movie(movieId, movieName) values(2, 'Alvin and the Chimpunks');
select * from T_XBBNHBS_Movie;