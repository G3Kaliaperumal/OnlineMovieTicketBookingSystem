/**
 * 
 */
function submitAction(act)
{
    document.registerForm.action = act;
    document.registerForm.submit();
};