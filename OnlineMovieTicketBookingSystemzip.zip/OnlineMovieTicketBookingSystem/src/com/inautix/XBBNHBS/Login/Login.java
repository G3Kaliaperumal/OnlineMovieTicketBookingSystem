package com.inautix.XBBNHBS.Login;

public class Login {

	public boolean validate(LoginBean loginBean) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		boolean result = false;
		LoginDao dao = new LoginDao();
		result = dao.validate(loginBean);
		return result;
	}

	public boolean validateSignUp(LoginBean loginBean) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		boolean result = false;
		LoginDao dao = new LoginDao();
		result = dao.validateSignUp(loginBean);
		return result;
	}

	public boolean validateRater(LoginBean loginBean) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		boolean result = false;
		LoginDao dao = new LoginDao();
		result = dao.validateRater(loginBean);
		return result;
	}

	public boolean validateSignUpReviewer(LoginBean loginBean) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		boolean result = false;
		LoginDao dao = new LoginDao();
		result = dao.validateSignUpReviewer(loginBean);
		return result;
	}
	
}
