package com.inautix.XBBNHBS.Login;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import DBUtil.ConnectionManager;

public class LoginDao {

	public boolean validate(LoginBean loginBean) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		boolean result = false;
		String password = null;
		PreparedStatement stmt = null;
		Connection con= ConnectionManager.getDBConnection();
		ResultSet rs=null;
		String query="SELECT password FROM T_XBBNHBS_ViewerDetails where phoneNumber = ? ";
		try{
			stmt = con.prepareStatement(query);
			stmt.setString(1, loginBean.getUserName());
			rs = stmt.executeQuery();
			while(rs.next()){
				password = rs.getString(1);
				if(password.equals(loginBean.getPassword())){
					result = true;
				}
			}
			if(password == null){
				result = false;
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally
		{
			if(rs!=null)
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(stmt!=null)
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			try {
				con.commit();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return result;
	}

	public boolean validateSignUp(LoginBean loginBean) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		boolean result = true;
		PreparedStatement stmt = null;
		Connection con= ConnectionManager.getDBConnection();
		ResultSet rs=null;
		String query="SELECT * FROM T_XBBNHBS_ViewerDetails where phoneNumber = ? ";
		try{
			stmt = con.prepareStatement(query);
			stmt.setString(1, loginBean.getUserName());
			rs = stmt.executeQuery();
			while(rs.next()){
				result = false;
				}
			if(result){
				query = "insert into T_XBBNHBS_ViewerDetails(viewerId, viewerName, phoneNumber, password) values(?, ?, ?, ?, ?)";
				stmt = con.prepareStatement(query);
				loginBean.setId(getViewerId()+1);
				stmt.setInt(1, loginBean.getId());
				stmt.setString(2, loginBean.getName());
				stmt.setString(3, loginBean.getUserName());
				stmt.setString(4, loginBean.getPassword());
				stmt.executeUpdate();
				
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally
		{
			if(rs!=null)
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(stmt!=null)
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			try {
				con.commit();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return result;
	}

	private int getViewerId() throws ClassNotFoundException {
		// TODO Auto-generated method stub
		int id = 0;
		PreparedStatement stmt = null;
		Connection con= ConnectionManager.getDBConnection();
		ResultSet rs = null;
		String query = "select * from T_XBBNHBS_ViewerDetails";
		try{
			stmt = con.prepareStatement(query);
			rs = stmt.executeQuery();
			while(rs.next()){
				++id;
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally
		{
			if(rs!=null)
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(stmt!=null)
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			try {
				con.commit();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return id;
	}

	public boolean validateRater(LoginBean loginBean) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		boolean result = false;
		String password = null;
		PreparedStatement stmt = null;
		Connection con= ConnectionManager.getDBConnection();
		ResultSet rs=null;
		String query="SELECT password FROM T_XBBNHBS_MovieRaterDetails where phoneNumber = ? ";
		try{
			stmt = con.prepareStatement(query);
			stmt.setString(1, loginBean.getUserName());
			rs = stmt.executeQuery();
			while(rs.next()){
				password = rs.getString(1);
				if(password.equals(loginBean.getPassword())){
					result = true;
				}
			}
			if(password == null){
				result = false;
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally
		{
			if(rs!=null)
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(stmt!=null)
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			try {
				con.commit();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return result;
	}

	public boolean validateSignUpReviewer(LoginBean loginBean) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		boolean result = true;
		PreparedStatement stmt = null;
		Connection con= ConnectionManager.getDBConnection();
		ResultSet rs=null;
		String query="SELECT * FROM T_XBBNHBS_MovieRaterDetails where phoneNumber = ? ";
		try{
			stmt = con.prepareStatement(query);
			stmt.setString(1, loginBean.getUserName());
			rs = stmt.executeQuery();
			while(rs.next()){
				result = false;
				}
			if(result){
				query = "insert into T_XBBNHBS_MovieRaterDetails(movieRaterId, movieRaterName, phoneNumber, email, address, password) values(?, ?, ?, ?, ?, ?)";
				stmt = con.prepareStatement(query);
				loginBean.setId(getRaterId()+1);
				stmt.setInt(1, loginBean.getId());
				stmt.setString(2, loginBean.getName());
				stmt.setString(3, loginBean.getUserName());
				stmt.setString(4, loginBean.getEmail());
				stmt.setString(5, loginBean.getAddress());
				stmt.setString(6, loginBean.getPassword());
				stmt.executeUpdate();
				
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally
		{
			if(rs!=null)
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(stmt!=null)
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			try {
				con.commit();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return result;
	}

	private int getRaterId() throws ClassNotFoundException {
		// TODO Auto-generated method stub
		int id = 0;
		PreparedStatement stmt = null;
		Connection con= ConnectionManager.getDBConnection();
		ResultSet rs = null;
		String query = "select * from T_XBBNHBS_MovieRaterDetails";
		try{
			stmt = con.prepareStatement(query);
			rs = stmt.executeQuery();
			while(rs.next()){
				++id;
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally
		{
			if(rs!=null)
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(stmt!=null)
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			try {
				con.commit();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return id;
	}
	
}
