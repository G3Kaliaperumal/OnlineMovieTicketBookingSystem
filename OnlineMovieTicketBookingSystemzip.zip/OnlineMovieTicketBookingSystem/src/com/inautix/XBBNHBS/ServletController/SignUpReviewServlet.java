package com.inautix.XBBNHBS.ServletController;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.inautix.XBBNHBS.Login.Login;
import com.inautix.XBBNHBS.Login.LoginBean;

public class SignUpReviewServlet extends HttpServlet{
	public void doPost(HttpServletRequest request, HttpServletResponse response)  
	        throws ServletException, IOException{
		try {
			validateRater(request, response);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}

	private void validateRater(HttpServletRequest request,
			HttpServletResponse response) throws IOException, ClassNotFoundException, ServletException {
		// TODO Auto-generated method stub
		LoginBean loginBean = new LoginBean();
		Login login = new Login();
		boolean result = false;
		
		response.setContentType("text/html");  
	    PrintWriter out = response.getWriter(); 
	    
	    String userName = request.getParameter("userName");
	    String password = request.getParameter("password");
	    String address = request.getParameter("state");
	    String name = request.getParameter("name");
	    String email = request.getParameter("email");
	    
	    loginBean.setUserName(userName);
	    loginBean.setPassword(password);
	    loginBean.setAddress(address);
	    loginBean.setEmail(email);
	    loginBean.setName(name);
	    
	    result = login.validateSignUpReviewer(loginBean);
	    
	    if(result){
	    	response.sendRedirect("review.html"); 
	    }
	    else{
	    	out.print("Sorry Username(Mobile Number) already exists!");
	    	RequestDispatcher requestDispatcher = request.getRequestDispatcher("/loginReview.html");
	    	requestDispatcher.include(request, response);
	    }
	    
	}
}
