package com.inautix.XBBNHBS.TheatreDetails;

public class TheatreDetailsBean {
	private int theatreId;
	private String theatreName;
	
	public int getTheatreId() {
		return theatreId;
	}
	
	public void setTheatreId(int theatreId) {
		this.theatreId = theatreId;
	}
	
	public String getTheatreName() {
		return theatreName;
	}
	
	public void setTheatreName(String theatreName) {
		this.theatreName = theatreName;
	}
	
}
