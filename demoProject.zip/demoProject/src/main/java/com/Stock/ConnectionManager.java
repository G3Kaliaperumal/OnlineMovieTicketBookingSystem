package com.Stock;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionManager {

        public static Connection getDBConnection() throws ClassNotFoundException {

                Connection con = null;
                /*Class.forName("oracle.jdbc.driver.OracleDriver");*/
                Class.forName("org.apache.derby.jdbc.ClientDriver");
                try {
                        /*con = DriverManager.getConnection(

                                       "jdbc:oracle:thin:@10.232.71.29:1521:INATP02", "shobana",

                                        "shobana");*/
                	con = DriverManager.getConnection("jdbc:derby://172.24.19.152:1527/sample;create=true;user=sample;password=pwd");
                } catch (SQLException e) {

                        e.printStackTrace();

                }

                return con;

        }

}

