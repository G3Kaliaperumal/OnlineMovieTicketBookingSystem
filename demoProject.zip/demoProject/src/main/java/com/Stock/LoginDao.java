package com.Stock;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class LoginDao {

	public boolean validate(LoginBean loginBean) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		boolean result = false;
		String password = null;
		PreparedStatement stmt = null;
		Connection con= ConnectionManager.getDBConnection();
		ResultSet rs=null;
		String query="SELECT password FROM T_XBBNHBS_ViewerDetails where phoneNumber = ? ";
		try{
			stmt = con.prepareStatement(query);
			stmt.setString(1, loginBean.getUserName());
			rs = stmt.executeQuery();
			while(rs.next()){
				password = rs.getString(1);
				if(password.equals(loginBean.getPassword())){
					result = true;
				}
			}
			if(password == null){
				result = false;
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally
		{
			if(rs!=null)
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(stmt!=null)
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			try {
				con.commit();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return result;
	}

	public boolean validateSignUp(LoginBean loginBean) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		boolean result = true;
		PreparedStatement stmt = null;
		Connection con= ConnectionManager.getDBConnection();
		ResultSet rs=null;
		String query="SELECT * FROM T_XBBNHBS_ViewerDetails where phoneNumber = ? ";
		try{
			stmt = con.prepareStatement(query);
			System.out.println(loginBean.getUserName());
			stmt.setString(1, loginBean.getUserName());
			rs = stmt.executeQuery();
			while(rs.next()){
				System.out.println(loginBean.getUserName());
				result = false;
				}
			if(result){
				query = "insert into T_XBBNHBS_ViewerDetails(viewerId, viewerName, phoneNumber, password) values(?, ?, ?, ?)";
				PreparedStatement statement = con.prepareStatement(query);
				loginBean.setId(getViewerId()+1);
				statement.setInt(1, loginBean.getId());
				statement.setString(2, loginBean.getName());
				statement.setString(3, loginBean.getUserName());
				statement.setString(4, loginBean.getPassword());
				statement.executeUpdate();
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally
		{
			if(rs!=null)
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(stmt!=null)
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			try {
				con.commit();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return result;
	}

	public int getViewerId() throws ClassNotFoundException {
		// TODO Auto-generated method stub
		int id = 0;
		PreparedStatement stmt = null;
		Connection con= ConnectionManager.getDBConnection();
		ResultSet rs = null;
		String query = "select * from T_XBBNHBS_ViewerDetails";
		try{
			stmt = con.prepareStatement(query);
			rs = stmt.executeQuery();
			while(rs.next()){
				++id;
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally
		{
			if(rs!=null)
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(stmt!=null)
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			try {
				con.commit();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return id;
	}
	
	public int getViewerId(String userName) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		int id = 0;
		PreparedStatement stmt = null;
		Connection con= ConnectionManager.getDBConnection();
		ResultSet rs = null;
		String query = "select * from T_XBBNHBS_ViewerDetails where phoneNumber = ?";
		try{
			stmt = con.prepareStatement(query);
			stmt.setString(1, userName);
			rs = stmt.executeQuery();
			while(rs.next()){
				id = rs.getInt(1);
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally
		{
			if(rs!=null)
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(stmt!=null)
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			try {
				con.commit();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return id;
	}

	public boolean validateRater(LoginBean loginBean) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		boolean result = false;
		String password = null;
		PreparedStatement stmt = null;
		Connection con= ConnectionManager.getDBConnection();
		ResultSet rs=null;
		String query="SELECT password FROM T_XBBNHBS_MovieRaterDetails where phoneNumber = ? ";
		try{
			stmt = con.prepareStatement(query);
			stmt.setString(1, loginBean.getUserName());
			rs = stmt.executeQuery();
			while(rs.next()){
				password = rs.getString(1);
				if(password.equals(loginBean.getPassword())){
					result = true;
				}
			}
			if(password == null){
				result = false;
			}
		}
		catch(SQLException e){
			return false;
		}
		finally
		{
			if(rs!=null)
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(stmt!=null)
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			try {
				con.commit();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return result;
	}

	public boolean validateSignUpReviewer(LoginBean loginBean) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		boolean result = true;
		PreparedStatement stmt = null;
		Connection con= ConnectionManager.getDBConnection();
		ResultSet rs=null;
		String query="SELECT * FROM T_XBBNHBS_MovieRaterDetails where phoneNumber = ? ";
		try{
			stmt = con.prepareStatement(query);
			stmt.setString(1, loginBean.getUserName());
			rs = stmt.executeQuery();
			while(rs.next()){
				result = false;
				}
			if(result){
				query = "insert into T_XBBNHBS_MovieRaterDetails(movieRaterId, movieRaterName, phoneNumber, email, address, password) values(?, ?, ?, ?, ?, ?)";
				PreparedStatement statement = con.prepareStatement(query);
				loginBean.setId(getRaterId()+1);
				statement.setInt(1, loginBean.getId());
				statement.setString(2, loginBean.getName());
				statement.setString(3, loginBean.getUserName());
				statement.setString(4, loginBean.getEmail());
				statement.setString(5, loginBean.getAddress());
				statement.setString(6, loginBean.getPassword());
				statement.executeUpdate();
				
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally
		{
			if(rs!=null)
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(stmt!=null)
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			try {
				con.commit();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return result;
	}

	private int getRaterId() throws ClassNotFoundException {
		// TODO Auto-generated method stub
		int id = 0;
		PreparedStatement stmt = null;
		Connection con= ConnectionManager.getDBConnection();
		ResultSet rs = null;
		String query = "select * from T_XBBNHBS_MovieRaterDetails";
		try{
			stmt = con.prepareStatement(query);
			rs = stmt.executeQuery();
			while(rs.next()){
				++id;
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally
		{
			if(rs!=null)
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(stmt!=null)
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			try {
				con.commit();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return id;
	}
	
}
