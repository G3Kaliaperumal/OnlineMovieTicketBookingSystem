package com.Stock;



public class MovieRateBean {
	private int movieId;
	private int movieRaterId;
	private int movieRate;
	
	public int getMovieId() {
		return movieId;
	}
	
	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}
	
	public int getMovieRaterId() {
		return movieRaterId;
	}
	
	public void setMovieRaterId(int movieRaterId) {
		this.movieRaterId = movieRaterId;
	}
	
	public int getMovieRate() {
		return movieRate;
	}
	
	public void setMovieRate(int movieRate) {
		this.movieRate = movieRate;
	}
	
}
