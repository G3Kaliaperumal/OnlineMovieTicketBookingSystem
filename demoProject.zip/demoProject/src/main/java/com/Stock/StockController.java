package com.Stock;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(value = "/stocks")

public class StockController {


	
	 
	  @RequestMapping(value = "/all" , method = RequestMethod.GET )
	  public /*String*/List<StockBean> getAllStocks() {
    	
		ArrayList<StockBean> list = new ArrayList<StockBean>();  
		list.add(new StockBean("INFY", "INFOSYS TECHNOLOGIES"));
		
    	return list;
      }	

    
}