package com.Stock;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(value = "/tickets")

public class TicketController {
	
	@RequestMapping(value = "/all" , method = RequestMethod.GET )
	public List<TicketBean> getTickets() throws ClassNotFoundException{
		TicketDao dao = new TicketDao();
		ArrayList<TicketBean> tickets = (ArrayList<TicketBean>) dao.getTicketDetails();
		return tickets;
	}
	
	@RequestMapping(value = "/tickets" , method = RequestMethod.POST, consumes={MediaType.APPLICATION_JSON_VALUE}
	,produces={MediaType.APPLICATION_JSON_VALUE})
	public void createTicket(@RequestBody TicketBean ticket){
		TicketDao dao = new TicketDao();
		
	}

}
